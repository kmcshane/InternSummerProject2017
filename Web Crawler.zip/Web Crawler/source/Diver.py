# -*- coding: utf-8 -*-
"""
Created on Thu Jun 15 14:21:24 2017

@author: tdd30784
"""

import requests
from bs4 import BeautifulSoup

catalogKeyTerms = \
['ROVs', 'Remotely Operated Vehicle', 'Drone', 'under', 'water']

altCatKeyTerms = \
['product', 'equipment', 'seller', 'buy']

altCatKeyTerms = \
['product', 'equipment', 'seller', 'buy']

ROVpageKeyTerms = \
['rov', 'remote', 'vehicle', 'drone', 'robot', 'learn', 'see', 'spec',]

ROVindex = set()
catalogs = set()
productCats = set()
class Diver():
    #returns an array with the following information:
    #[ModelName, Weight, Depth/Range]
    
    #takes a manufacturer link
    def __init__():
        print('diver started')
    
    
    #Gathers information on an individual ROV page 
    def isDuplicte(link=''):
        for html in catalogs:
            if(html == link):
                return 'true'
        return 'false'
    
    #the flagship method in Diver
    #Returns all ROVs from a manufacturers website
    def findROVs(self, soupObject = BeautifulSoup):
        
        #The first step is to find the catalog page:
        links = soupObject.find_all('a')
        for link in links:                       #pick a link' from the home page
            for keyTerm in catalogKeyTerms:      #cycle through key terms
                if(link.text.lower().contains(keyTerm)): #check if it contains a catalog key term
                    catalogs.update(link)        #if so, add it as a plausible catalog
                    break
                elif(link['herf'].lower().contains(keyTerm)): #checks href text
                    catalogs.update(link)                     #if so, add it as a plausible catalog
                    break
                
        #IF there are NO links with catalog key terms
        #THEN we are looking for product pages which lead to ROV catalog pages
        if(len(catalogs) == 0):
            for link in links:                                #pick a link from the home page
                for keyTerm in altCatKeyTerms:                #cycle through alternative key terms
                    if(link.text.lower().contains(keyTerm)):  #check if it contains an alternative key term
                        productCats.update(link)              #if so, add it as a plausible productcatalog
                        break
                    elif(link['herf'].text.lower().contains(keyTerm)): #checks href text
                        catalogs.update(link)                 #if so, add it as a plausible catalog
                        break
                    
            #Start checking product pages for ROV catalogs
            for product in productCats : #pick a potential product page
               #make beautiful soup object
               prodSoup = BeautifulSoup(requests.get(product.href).text, 'lxml') 
               prodLinks = prodSoup.find_all('a')       #gets all links in the product catalog
               for link in prodLinks:                   #pick a link from the product catalog
                   for keyTerm in catalogKeyTerms:      #cycle through catalog key terms
                       if(link.text.lower().contains(keyTerm)):
                          catalogs.update(link)        #if so, add it as a plausible catalog page
                          break
                       elif(link['herf'].text.lower().contains(keyTerm)):  #checks href text
                           catalogs.update(link)                           #if so, add it as a plausible catalog
                           break
        
        
        #If there are still NO items in the catalog, return NOTHING
        if(len(catalogs) == 0): 
            return 'NO_ROVS'
        
        #If there ARE items in the catalog, begin searching through them for 
        #ROV page links. There should only be a few catalog links, if not just one
        for catalog in catalogs:
            #store the catalog as a BeautifulSoup object
            localCatalog = BeautifulSoup(requests.get(catalog.href).text, 'lxml')
            possibleROVpages = localCatalog.find_all('a')
            #There are three ways code can flow to find ROV links:
                #1) It checks anchor and href text
                #2) It checks anchor class
                #3) It checks div that nests the anchor
            #They are ordered from most to least successful
            
            #ANCHOR TEXT CHECK
            for anchor in possibleROVpages:   
              if self.isDuplicate(anchor['href'])=='false':             #pick an anchor
                for keyTerm in ROVpageKeyTerms:                         #pick a key term for ROV pages
                    if(anchor.text.lower().contains(keyTerm)):          #check if its text contains a key term
                        ROVindex.update(anchor)                         #send link to collection of ROV pages
                        break;
                    elif(anchor['herf'].lower().contains(keyTerm)):     #check if its href contains a key term
                        ROVindex.update(anchor)
                        break;
            #CLASS CHECK
            
            #IF no links were found when checking tags/hrefs
            #THEN we check classes to see if we can find the links (if they exist)

            ClassDictionary = {}
            if(len(ROVindex) == 0):                                     #IF no links found earlier
                for anchor in possibleROVpages:                         #pick a link
                   if self.isDuplicate(anchor['href'])=='false':
                    for key in ClassDictionary:                         #pick a key from ClassDictionary
                        if(key == anchor["class"]):                     #If the key already exists
                            ClassDictionary[anchor["class"]] += 1       #Increment its value by 1
                    ClassDictionary[anchor["class"]] = 0                #If it did not exist, create an entry
                
                highestValueClass = ''                                  #stores the key with highest value
                for key in ClassDictionary:                             #pick a key
                    if(ClassDictionary[key] > highestValueClass):       #if it has a value higher than the last
                        highestValueClass = key                         #assign it as highest value
                
                for anchor in possibleROVpages:                         #pick a link
                    if(anchor['class'] == key):                         #if its class equals the highest val class                        
                        ROVindex.update(anchor)                         #record it as a ROV index
                
                #<DIV/DIV> CHECK (optional)
                
                #IF no links were found when checking tags/hrefs NOR
                #when checking for class anchors
                #THEN try to find anchors by <div> type'
                
                #PRINTING FOR TESTING PURPOSES
                for link in ROVindex:
                    print(link['href'])
 
      
    
    def getRovInfo():
        print('hello')
       
    
            
            
            
                
                
        