# -*- coding: utf-8 -*-
#import urllib2
import requests
import Diver
from bs4 import BeautifulSoup


#GET urllib2
#ask kurt roettiger abiyt UACC network

proxyDic = {'http' : '10.20.19.37',
            'https' : '10.20.19.37'}

proxyAuth = ('30784', 'Wed');


dataCollected = []

toVisit = []
visited = []
listOfManufacturers = {}

#the html parameter is a link to a list of ROVs
def basic_webcrawl(html = '', maxpagedives = 0):
    
    
    #prepares page as a beautiful soup object
    source = requests.get(html,proxies = proxyDic, auth = proxyAuth);
    sourceText = source.text;
    soupText = BeautifulSoup(sourceText, "lxml");
    
    
    #notes that it has visited the seed page already
    visited.append(html)

    #finds manufacturer links and adds them to a que of pages to visit
    #also starts making dictionary of manufacturers
    listOfManufacturers = soupText.find_all('strong')
    for tag in listOfManufacturers:
        anchor = tag.findChild('a')
        toVisit.append(anchor)
        listOfManufacturers[anchor.text];
    
    #starts diving into the manufacturers' pages
    for link in toVisit:
        req = requests.get(link.href)
        manufacturer = BeautifulSoup(req.text, 'lxml')
        
        #lets say I want a method that returns an array of properties e.g.:
            # [manufacturer, model name, pdf link]
            # OR ideally
            # [manufacturer, model name, range, size, speed. etc]
        #We'll call it findROVs and make it part of a class called diver
        
        
        #findROVs takes a beautifulsoup object and returns 
        diver = Diver()
        dataCollected.append(diver.findROVs(manufacturer)); 
        
       
        #How the ROV arrays are organized
            #A manufacturer 
        
    
    
    print(soupText.prettify)

    
def openproxy():
    
    url = '10.20.19.37'
    username = '30784'
    password = 'Tue'
    password_mgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
    # None, with the "WithDefaultRealm" password manager means
    # that the user/pass will be used for any realm (where
    # there isn't a more specific match).
    password_mgr.add_password(None, url, username, password)
    auth_handler = urllib2.HTTPBasicAuthHandler(password_mgr)
    opener = urllib2.build_opener(auth_handler)
    urllib2.install_opener(opener)


link = 'http://www.rov.org/industry_manufacturers.cfm'
#openproxy()
basic_webcrawl(link)



